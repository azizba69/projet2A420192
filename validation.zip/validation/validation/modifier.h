#ifndef MODIFIER_H
#define MODIFIER_H

#include <QDialog>

namespace Ui {
class modifier;
}

class modifier : public QDialog
{
    Q_OBJECT

public:
    explicit modifier(QWidget *parent = nullptr);
    ~modifier();

private slots:
    void on_accueil_clicked();

    void on_confirmer_clicked();

    void on_id_sai_mod_editingFinished();

    void on_supprimer_2_currentIndexChanged(const QString &arg1);

    void on_modifier_3_currentIndexChanged(const QString &arg1);

    void on_ajouter_2_currentIndexChanged(const QString &arg1);

    void on_supprimer_clicked();

private:
    Ui::modifier *ui;
};

#endif // MODIFIER_H
