#include "annonces.h"

annonces::annonces()
{
        ID_ann="";
        Prix_ann=0;
        Type_ann="";
        Nom_ann="";
}
annonces::annonces(QString id,double prix,QString types,QDate debut,QDate fin,QString nom)
{
    this->ID_ann=id;
    this->Prix_ann=prix;
    this->Type_ann=types;
    this->debut_ann=debut;
    this->fin_ann=fin;
    this->Nom_ann=nom;
}
bool annonces::ajouter_ann()
{
    QSqlQuery query;
    QString res=QString::number(Prix_ann);
    query.prepare("INSERT INTO annonces (id,nom,type,prix,date_debut,date_fin) VALUES (:id, :nom, :type, :prix, :date_debut, :date_fin)");
    query.bindValue(":id",ID_ann);
    query.bindValue(":type",Type_ann);
    query.bindValue(":date_debut",debut_ann);
    query.bindValue(":date_fin",fin_ann);
    query.bindValue(":nom",Nom_ann);
    query.bindValue(":prix",res);
    return query.exec();
}
QSqlQueryModel * annonces::afficher_ann()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from annonces");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("type"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prix"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("date_debut"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("date_fin"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("nom"));
    return model;
}
bool annonces::supprimer_ann(QString idd)
{
    QSqlQuery query;

    query.prepare("Delete from annonces where ID = :id ");
    query.bindValue(":id", idd);
    return    query.exec();
}
bool annonces::modifier_ann(QString idd,QString nom,QString a,double b,QDate d,QDate e)
{
    QSqlQuery query;
    QString res=QString::number(b);
    query.prepare("UPDATE annonces SET nom = :nom,type = :type,prix = :prix,date_debut = :date_debut,date_fin = :date_fin  WHERE ID = :id ");
    query.bindValue(":id",idd);
    query.bindValue(":nom",nom);
    query.bindValue(":type",a);
    query.bindValue(":date_debut",d);
    query.bindValue(":date_fin",e);
    query.bindValue(":prix",res);
    return    query.exec();
}
QSqlQueryModel * annonces::tri_ann()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    model->setQuery("SELECT * FROM annonces ORDER BY prix");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("type"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prix"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("date_debut"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("date_fin"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("nom"));
    return model;
}
QSqlQueryModel * annonces::rechercher_ann(QString a)
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery query;
    query.prepare("SELECT * FROM annonces where id = :id");
    query.bindValue(":id",a);
    query.exec();
    model->setQuery(query);
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("type"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("prix"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("date_debut"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("date_fin"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("nom"));
        return model;
}

