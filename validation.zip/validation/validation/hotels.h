#ifndef HOTELS_H
#define HOTELS_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include "annonces.h"

class hotels : public annonces
{
private:
    QString ID_Hotel;
    QString hebergement;
    int nbr_nuit;
    QString services;
public:
    hotels();
    hotels(QString,QString,int,QString);
    hotels(QString,int,QString,QString,QString,QDate,QDate,QString,double);
    bool ajouter_hotel(QString,QDate,QDate,QString,double);

};

#endif // HOTELS_H
