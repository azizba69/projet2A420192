#ifndef CROISSIERES_H
#define CROISSIERES_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include "annonces.h"

class croissieres : public annonces
{
private:
    QString destination;
    QString escale;
    QString duree;
    QString ID_cr;
public:
    croissieres();
    croissieres(QString,QString,QString,QString);
    bool ajouter_croissieres(QString,QDate,QDate,QString,double);
};

#endif // CROISSIERES_H
