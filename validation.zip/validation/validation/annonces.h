#ifndef ANNONCES_H
#define ANNONCES_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QDate>
#include <QSqlQueryModel>
#include <QSqlQuery>
#include <QString>

class annonces
{
protected:
    QString ID_ann;
    double Prix_ann;
    QString Type_ann;
    QDate debut_ann;
    QDate fin_ann;
    QString Nom_ann;

public:
    annonces();
    annonces(QString,double,QString,QDate,QDate,QString);
    bool ajouter_ann();
    QSqlQueryModel * afficher_ann();
    bool supprimer_ann(QString);
    bool modifier_ann(QString,QString,QString,double,QDate,QDate);
    QSqlQueryModel * tri_ann();
    QSqlQueryModel * rechercher_ann(QString);
    QSqlQueryModel * rechercher2(QString a);

};

#endif // ANNONCES_H
