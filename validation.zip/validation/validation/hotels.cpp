#include "hotels.h"

hotels::hotels()
{
    ID_Hotel="";
    hebergement="";
    services="";
    nbr_nuit=0;
}
hotels::hotels(QString id,QString he,int nbr,QString ser)
{
    this->ID_Hotel=id;
    this->hebergement=he;
    this->nbr_nuit=nbr;
    this->services=ser;
}
hotels::hotels(QString id,int nbr_nuit,QString hebergement,QString services,QString types,QDate debut,QDate fin,QString nom,double prix)
{
    annonces(id,prix,types,debut,fin,nom);
    this->ID_Hotel=id;
    this->hebergement=hebergement;
    this->services=services;
    this->nbr_nuit=nbr_nuit;
}
bool hotels::ajouter_hotel(QString e,QDate a,QDate b,QString c,double d)
{
    QSqlQuery query;
    QString res=QString::number(d);
    QString res1=QString::number(nbr_nuit);
    query.prepare("INSERT INTO hotels (id,hebergement,nombre_de_nuit,services,date_fin,date_debut,nom,type,prix) "
              "VALUES (:id, :hebergement, :nombre_de_nuit, :services, :date_fin, :date_debut, :nom, :type, :prix)");
    query.bindValue(":id",ID_Hotel);
    query.bindValue(":type",e);
    query.bindValue(":date_debut",a);
    query.bindValue(":date_fin",b);
    query.bindValue(":nom",c);
    query.bindValue(":prix",res);
    query.bindValue(":hebergement",hebergement);
    query.bindValue(":services",services);
    query.bindValue(":nombre_de_nuit",res1);
    return query.exec();
}
