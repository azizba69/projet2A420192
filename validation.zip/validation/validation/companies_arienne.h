#ifndef COMPANIES_ARIENNE_H
#define COMPANIES_ARIENNE_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include "annonces.h"

class companies_arienne : public annonces
{
private:
    QString ID_CA;
    QString ville_depart;
    QString ville_arrive;
    QString classe_dipo;
public:
    companies_arienne();
    companies_arienne(QString,QString,QString,QString);
    bool ajouter_CA(QString e,QDate a,QDate b,QString c,double d);
};

#endif // COMPANIES_ARIENNE_H
