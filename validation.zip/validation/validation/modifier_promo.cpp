#include "modifier_promo.h"
#include "ui_modifier_promo.h"

#include "ajout.h"
#include "modifier.h"
#include "supprimer.h"
#include "ajut_promo.h"
#include "modifier_promo.h"
#include "supprimer_promo.h"
#include "accueil.h"
#include "promotions.h"
modifier_promo::modifier_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modifier_promo)
{
    ui->setupUi(this);
}

modifier_promo::~modifier_promo()
{
    delete ui;
}

void modifier_promo::on_pushButton_clicked()
{
    accueil a;
    a.show();
    modifier_promo::hide();
    a.exec();
}

void modifier_promo::on_ajouter_currentIndexChanged(const QString &arg1)
{
       if (arg1 == "annonces")
       {
           ajout a;
           a.show();
           modifier_promo::hide();
           a.exec();
       }
       else {
           ajut_promo a;
           a.show();
           modifier_promo::hide();
           a.exec();
       }
}

void modifier_promo::on_modifier_currentIndexChanged(const QString &arg1)
{
    if (arg1 == "annonces")
    {
        modifier a;
        a.show();
        modifier_promo::hide();
        a.exec();
    }

}

void modifier_promo::on_supprimer_currentIndexChanged(const QString &arg1)
{
    if (arg1 == "annonces")
    {
        supprimer a;
        a.show();
        modifier_promo::hide();
        a.exec();
    }
    else {
        supprimer_promo a;
        a.show();
        modifier_promo::hide();
        a.exec();
    }
}

void modifier_promo::on_pushButton_4_clicked()
{
    supprimer s;
    s.show();
    modifier_promo::hide();
    s.exec();
}

void modifier_promo::on_pushButton_6_clicked()
{
    QString idd = ui->id_mod->text();
    QString type = ui->type->text();
    double prix = ui->prix->text().toDouble();
    QString nom= ui->nom->text();
    promotions p(idd,nom,type,prix);
    bool test= p.modifier_promotions(idd,nom,type,prix);
}

void modifier_promo::on_pushButton_7_clicked()
{
    QString id_ann = ui->lineEdit_3->text();
    QString id_pro = ui->id->text();
    double red = ui->lineEdit_2->text().toDouble();
    QSqlQuery query_pro;
    QSqlQuery query_ann;
    QString r = QString::number(red);
    query_ann.prepare("select * from annonces where id= :id");
    query_ann.bindValue(":id",id_ann);
    query_ann.exec();
    query_pro.prepare("select * from promotions where id= :id");
    query_pro.bindValue(":id",id_pro);
    query_pro.exec();

    if(query_ann.exec())
    {
        query_ann.prepare("update annonces set prix = :res where id =:id");
        query_ann.bindValue(":id",id_ann);
        query_ann.bindValue(":res",r);
        query_ann.exec();
        setStyleSheet("QPushButton#pushbutton_7{color:lime}");
    }


}
