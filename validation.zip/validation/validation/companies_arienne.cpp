#include "companies_arienne.h"

companies_arienne::companies_arienne()
{

}
companies_arienne::companies_arienne(QString id,QString vd,QString va,QString cl)
{
    this->classe_dipo = cl;
    this->ville_arrive = va;
    this->ville_depart = vd;
    this->ID_CA = id;
}
bool companies_arienne::ajouter_CA(QString e,QDate a,QDate b,QString c,double d)
{
    QSqlQuery query;
    QString res=QString::number(d);
    query.prepare("INSERT INTO companies_aerienne(id,date_fin,date_debut,nom,type,prix,classe,ville_depart,ville_arriver) "
              "VALUES (:id, :date_fin, :date_debut, :nom, :type, :prix , :classe, :ville_depart, :ville_arriver)");
    query.bindValue(":id",ID_CA);
    query.bindValue(":type",e);
    query.bindValue(":date_debut",a);
    query.bindValue(":date_fin",b);
    query.bindValue(":nom",c);
    query.bindValue(":prix",res);
    query.bindValue(":classe",classe_dipo);
    query.bindValue(":ville_depart",ville_arrive);
    query.bindValue(":ville_arriver",ville_depart);
    return query.exec();
}
