#ifndef MODIFIER_PROMO_H
#define MODIFIER_PROMO_H

#include <QDialog>

namespace Ui {
class modifier_promo;
}

class modifier_promo : public QDialog
{
    Q_OBJECT

public:
    explicit modifier_promo(QWidget *parent = nullptr);
    ~modifier_promo();

private slots:
    void on_pushButton_clicked();

    void on_ajouter_currentIndexChanged(const QString &arg1);

    void on_modifier_currentIndexChanged(const QString &arg1);

    void on_supprimer_currentIndexChanged(const QString &arg1);

    void on_pushButton_4_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

private:
    Ui::modifier_promo *ui;
};

#endif // MODIFIER_PROMO_H
