#include "accueil.h"
#include "ui_accueil.h"
#include "ajout.h"
#include "modifier.h"
#include "supprimer.h"
#include "ajut_promo.h"
#include "modifier_promo.h"
#include "supprimer_promo.h"
#include <QPropertyAnimation>

accueil::accueil(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::accueil)
{
    ui->setupUi(this);
    //ui->table_annonces->setModel(tmpannonces.afficher_ann());
    ui->tab_a->setModel(tmpannonces.afficher_ann());
    ui->tab_p->setModel(tmpromotions.affciher_promotions());
    for (int i=0;i<6;i++)
         ui->tab_a->setColumnWidth(i,  ui->tab_a->width()/6);
     for (int i=0;i<4;i++)
         ui->tab_p->setColumnWidth(i,  ui->tab_p->width()/4);
}

accueil::~accueil()
{
    delete ui;
}
void accueil::on_modifier_clicked()
{
    modifier m;
    m.show();
    accueil::hide();
    m.exec();
}

void accueil::on_supprimer_clicked()
{
    supprimer s;
    s.show();
    accueil::hide();
    s.exec();
}

void accueil::on_afficher_clicked()
{

}
void accueil::on_pushButton_2_clicked()
{
    annonces a;
    ui->tab_a->setModel(tmpannonces.tri_ann());
}

void accueil::on_pushButton_3_clicked()
{
    annonces a;
    QString b=ui->a->text();
    ui->tab_a->setModel(tmpannonces.rechercher_ann(b));

}





void accueil::on_pro_ou_ann_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        ajout a;
        a.show();
        accueil::hide();
        a.exec();
    }
    if(arg1 =="promotions")
    {
        ajut_promo a;
        a.show();
        accueil::hide();
        a.exec();
    }
}

void accueil::on_mod_pro_ou_ann_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        modifier a;
        a.show();
        accueil::hide();
        a.exec();
    }
    if(arg1 =="promotions")
    {
        modifier_promo a;
        a.show();
        accueil::hide();
        a.exec();
    }
}

void accueil::on_sup_pro_ou_ann_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        supprimer s;
        s.show();
        accueil::hide();
        s.exec();
    }
    if(arg1 =="promotions")
    {
        supprimer_promo s;
        s.show();
        accueil::hide();
        s.exec();
    }
}

void accueil::on_tri_p_clicked()
{
    promotions a;
    ui->tab_p->setModel(tmpromotions.tri());
}
