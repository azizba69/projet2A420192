#ifndef TRANSPORT_H
#define TRANSPORT_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include "annonces.h"

class transport : public annonces
{
private:
    QString circuit;
    double duree;
    QString type;
    QString ID_tr;
public:
    transport();
    transport(QString,QString,double,QString);
    bool ajouter_transport(QString e,QDate a,QDate b,QString c,double d);

};

#endif // TRANSPORT_H
