#include "croisieres.h"

croissieres::croissieres()
{

}
croissieres::croissieres(QString des,QString esc,QString dur,QString id)
{
    this->destination = des;
    this->escale = esc;
    this->duree = dur;
    this->ID_cr = id;
}
bool croissieres::ajouter_croissieres(QString e, QDate a, QDate b, QString c, double d)
{
    QSqlQuery query;
    QString res=QString::number(d);
    query.prepare("INSERT INTO croisiere(id,date_fin,date_debut,nom,type,prix,destination,escale,duree) "
              "VALUES (:id, :date_fin, :date_debut, :nom, :type, :prix , :destination, :escale, :duree)");
    query.bindValue(":id",ID_cr);
    query.bindValue(":type",e);
    query.bindValue(":date_debut",a);
    query.bindValue(":date_fin",b);
    query.bindValue(":nom",c);
    query.bindValue(":prix",res);
    query.bindValue(":destination",destination);
    query.bindValue(":escale",escale);
    query.bindValue(":duree",duree);
    return query.exec();
}
