#include "ajout.h"
#include "ui_ajout.h"

#include "accueil.h"
#include "modifier.h"
#include "supprimer.h"

#include "annonces.h"
#include "hotels.h"
#include "companies_arienne.h"
#include "croisieres.h"
#include "transport.h"



#include "modifier.h"
#include "supprimer.h"
#include "modifier_promo.h"
#include "supprimer_promo.h"
#include "ajut_promo.h"
#include <QMessageBox>
ajout::ajout(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajout)
{
    ui->setupUi(this);
    QDate d;
    QRegExp rx("[A-Za-z_]+");//[A-Za-z0-9_]
    QRegExp rx1("[0-9_]+");
    QValidator *validator = new QRegExpValidator(rx, this);
    QValidator *validator2 = new QRegExpValidator(rx1, this);
    ui->type->setValidator(validator);
    ui->nom->setValidator(validator);
    ui->id->setValidator(validator2);
    ui->debut->setDate(d.currentDate());
    ui->fin->setDate(d.currentDate());
}

ajout::~ajout()
{
    delete ui;
}

void ajout::on_accueil_clicked()
{
    accueil a;
    a.show();
    ajout::hide();
    a.exec();
}
void ajout::on_type_editingFinished()
{
    QString a;
    a=ui->type->text();
    if(a!="" && a!="hotel" && a!="transport" && a!="companie_aerienne" && a!="croisiere")
    {
    ui->type->setText("n'est pas valid");
    ui->type->setStyleSheet("QLineEdit#type{color:red}");
    }
    else
    {
    ui->type->setStyleSheet("QLineEdit#type{color:black}");
    }
    if(a=="hotel")
    {
    ui->classe->setStyleSheet("QLineEdit#classe{background-color:gainsboro}");
    ui->classe->setReadOnly(true);
    ui->escale->setStyleSheet("QLineEdit#escale{background-color:gainsboro}");
    ui->escale->setReadOnly(true);
    ui->circuit->setStyleSheet("QLineEdit#circuit{background-color:gainsboro}");
    ui->circuit->setReadOnly(true);
    ui->type_tr->setStyleSheet("QLineEdit#type_tr{background-color:gainsboro}");
    ui->type_tr->setReadOnly(true);
    ui->duree_cr->setStyleSheet("QLineEdit#duree_cr{background-color:gainsboro}");
    ui->duree_cr->setReadOnly(true);
    ui->duree_tr->setStyleSheet("QLineEdit#duree_tr{background-color:gainsboro}");
    ui->duree_tr->setReadOnly(true);
    ui->destination->setStyleSheet("QLineEdit#destination{background-color:gainsboro}");
    ui->destination->setReadOnly(true);
    ui->ville_ar->setStyleSheet("QLineEdit#ville_ar{background-color:gainsboro}");
    ui->ville_ar->setReadOnly(true);
    ui->ville_dp->setStyleSheet("QLineEdit#ville_dp{background-color:gainsboro}");
    ui->ville_dp->setReadOnly(true);
    }
    if(a=="transport")
    {
    ui->classe->setStyleSheet("QLineEdit#classe{background-color:gainsboro}");
    ui->classe->setReadOnly(true);
    ui->escale->setStyleSheet("QLineEdit#escale{background-color:gainsboro}");
    ui->escale->setReadOnly(true);
    ui->service->setStyleSheet("QLineEdit#service{background-color:gainsboro}");
    ui->service->setReadOnly(true);
    ui->hebergement->setStyleSheet("QLineEdit#hebergement{background-color:gainsboro}");
    ui->hebergement->setReadOnly(true);
    ui->duree_cr->setStyleSheet("QLineEdit#duree_cr{background-color:gainsboro}");
    ui->duree_cr->setReadOnly(true);
    ui->nombre_nuit->setStyleSheet("QLineEdit#nombre_nuit{background-color:gainsboro}");
    ui->nombre_nuit->setReadOnly(true);
    ui->destination->setStyleSheet("QLineEdit#destination{background-color:gainsboro}");
    ui->destination->setReadOnly(true);
    ui->ville_ar->setStyleSheet("QLineEdit#ville_ar{background-color:gainsboro}");
    ui->ville_ar->setReadOnly(true);
    ui->ville_dp->setStyleSheet("QLineEdit#ville_dp{background-color:gainsboro}");
    ui->ville_dp->setReadOnly(true);
    }
    if(a=="companie_aerienne")
    {
    ui->type_tr->setStyleSheet("QLineEdit#type_tr{background-color:gainsboro}");
    ui->type_tr->setReadOnly(true);
    ui->escale->setStyleSheet("QLineEdit#escale{background-color:gainsboro}");
    ui->escale->setReadOnly(true);
    ui->service->setStyleSheet("QLineEdit#service{background-color:gainsboro}");
    ui->service->setReadOnly(true);
    ui->hebergement->setStyleSheet("QLineEdit#hebergement{background-color:gainsboro}");
    ui->hebergement->setReadOnly(true);
    ui->duree_tr->setStyleSheet("QLineEdit#duree_tr{background-color:gainsboro}");
    ui->duree_tr->setReadOnly(true);
    ui->nombre_nuit->setStyleSheet("QLineEdit#nombre_nuit{background-color:gainsboro}");
    ui->nombre_nuit->setReadOnly(true);
    ui->destination->setStyleSheet("QLineEdit#destination{background-color:gainsboro}");
    ui->destination->setReadOnly(true);
    ui->circuit->setStyleSheet("QLineEdit#circuit{background-color:gainsboro}");
    ui->circuit->setReadOnly(true);
    ui->duree_cr->setStyleSheet("QLineEdit#duree_cr{background-color:gainsboro}");
    ui->duree_cr->setReadOnly(true);
    }
    if(a=="croisiere")
    {
        ui->type_tr->setStyleSheet("QLineEdit#type_tr{background-color:gainsboro}");
        ui->type_tr->setReadOnly(true);
        ui->ville_dp->setStyleSheet("QLineEdit#ville_dp{background-color:gainsboro}");
        ui->ville_dp->setReadOnly(true);
        ui->service->setStyleSheet("QLineEdit#service{background-color:gainsboro}");
        ui->service->setReadOnly(true);
        ui->hebergement->setStyleSheet("QLineEdit#hebergement{background-color:gainsboro}");
        ui->hebergement->setReadOnly(true);
        ui->duree_tr->setStyleSheet("QLineEdit#duree_tr{background-color:gainsboro}");
        ui->duree_tr->setReadOnly(true);
        ui->nombre_nuit->setStyleSheet("QLineEdit#nombre_nuit{background-color:gainsboro}");
        ui->nombre_nuit->setReadOnly(true);
        ui->classe->setStyleSheet("QLineEdit#classe{background-color:gainsboro}");
        ui->classe->setReadOnly(true);
        ui->circuit->setStyleSheet("QLineEdit#circuit{background-color:gainsboro}");
        ui->circuit->setReadOnly(true);
        ui->ville_ar->setStyleSheet("QLineEdit#ville_ar{background-color:gainsboro}");
        ui->ville_ar->setReadOnly(true);
    }
}

void ajout::on_id_editingFinished()
{
    QSqlQuery query;
    QString a;
    a=ui->id->text();

    query.prepare("SELECT ID from annonces where ID = :id ");
    query.bindValue(":id", a);
    query.exec();
    if(query.next())
    {
    ui->id->setText("exist deja ");
    ui->id->setStyleSheet("QLineEdit#id{color:red}");
    }
    else {
        ui->id->setStyleSheet("QLineEdit#id{color:black}");
    }
}





void ajout::on_confirmer_clicked()
{
    //annonces
    QString id = ui->id->text();
    QString type = ui->type->text();
    double prix = ui->prix->text().toDouble();
    QDate date_debut = ui->debut->date();
    QDate date_fin = ui->fin->date();
    QString nom= ui->nom->text();
    //hotel
    QString heberegemet = ui->hebergement->text();
    QString services = ui->service->text();
    int nbr_nuit = ui->nombre_nuit->text().toInt();
    //aerienne
    QString ville_dp = ui->ville_dp->text();
    QString ville_ar = ui->ville_ar->text();
    QString classe = ui->classe->text();
    //transport
    QString circuit = ui->circuit->text();
    double duree_tr = ui->duree_tr->text().toDouble();
    QString type_tr = ui->type_tr->text();
    //croisiere
    QString destination = ui->destination->text();
    QString escale = ui->escale->text();
    QString duree_cr = ui->duree_cr->text();


    annonces b(id,prix,type,date_debut,date_fin,nom);
    if(id!="" && type!="" && nom!="" && date_debut.operator<=(date_fin))
    {
    //ajouter annonce
    bool test=b.ajouter_ann();
    //ajouter hotel
    if(type=="hotel")
    {
    hotels h(id,heberegemet,nbr_nuit,services);
    if(heberegemet!="" && services!=""){
    bool test1=h.ajouter_hotel(type,date_debut,date_fin,nom,prix);
    if(test && test1)
    setStyleSheet("QPushButton#confirmer{color:lime}");
    }
    }
    //ajouter aerienne
    if(type=="companie_aerienne")
    {
     companies_arienne c(id,ville_dp,ville_ar,classe);
     bool test2=c.ajouter_CA(type,date_debut,date_fin,nom,prix);
     if(test && test2)
     setStyleSheet("QPushButton#confirmer{color:lime}");
    }
    //ajouter croisiere
    if(type=="croisiere")
    {
     croissieres c(escale,destination,duree_cr,id);
     bool test3=c.ajouter_croissieres(type,date_debut,date_fin,nom,prix);
     if(test && test3)
     setStyleSheet("QPushButton#confirmer{color:lime}");
    }
    //ajouter transport
    if(type=="transport")
    {
    transport c(id,type_tr,duree_tr,circuit);
    bool test4=c.ajouter_transport(type,date_debut,date_fin,nom,prix);
    if(test && test4)
    setStyleSheet("QPushButton#confirmer{color:lime}");
    }
    }
}

void ajout::on_ajouter_2_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "promotions")
    {
        ajut_promo a;
        a.show();
        ajout::hide();
        a.exec();
    }
}

void ajout::on_modifier_2_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        modifier m;
        m.show();
        ajout::hide();
        m.exec();
    }
    else {
        modifier_promo m;
        m.show();
        ajout::hide();
        m.exec();
    }
}

void ajout::on_supprimer_2_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        supprimer m;
        m.show();
        ajout::hide();
        m.exec();
    }
    else {
        supprimer_promo m;
        m.show();
        ajout::hide();
        m.exec();
    }
}






void ajout::on_supprimer_clicked()
{
    supprimer s;
    s.show();
    ajout::hide();
    s.exec();
}
