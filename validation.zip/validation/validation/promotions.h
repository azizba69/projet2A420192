#ifndef PROMOTIONS_H
#define PROMOTIONS_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>
#include <QtSql>
class promotions
{
private:
    QString ID_pro;
    double reduction;
    QString nom;
    QString type;
    double prix;
public:
    promotions();
    promotions(QString,QString,QString,double);
    bool ajouter_promotions();
    bool modifier_promotions(QString,QString,QString,double);
    bool supprimer_promotions(QString);
    QSqlQueryModel * affciher_promotions();
    QSqlQueryModel * tri();
    QSqlQueryModel * rechercher(QString id);
};

#endif // PROMOTIONS_H
