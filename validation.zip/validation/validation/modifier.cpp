#include "modifier.h"
#include "ui_modifier.h"
#include "accueil.h"
#include "ajout.h"
#include "supprimer.h"
#include "ajut_promo.h"
#include "modifier_promo.h"
#include "supprimer_promo.h"
#include <QMessageBox>
modifier::modifier(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::modifier)
{
    ui->setupUi(this);
}

modifier::~modifier()
{
    delete ui;
}

void modifier::on_accueil_clicked()
{
    accueil a;
    a.show();
    modifier::hide();
    a.exec();
}


void modifier::on_confirmer_clicked()
{
    QString idd = ui->id_sai_mod->text();
    QString type = ui->type_ann_mod->text();
    double prix = ui->prix_mod->text().toDouble();
    QDate date_debut = ui->debut_mod->date();
    QDate date_fin = ui->fin_mod->date();
    QString nom= ui->nom_mod->text();
    annonces a;
    bool test=a.modifier_ann(idd,nom,type,prix,date_debut,date_fin);

    if(test)
    {
        //ui->table_annonces->setModel(tmpannonces.afficher_ann());//refresh
        QMessageBox::information(nullptr, QObject::tr("Ajouter une annonce"),
                          QObject::tr("annonce ajouté.\n"
                                      "Click Cancel to exit."), QMessageBox::Cancel);
    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer un étudiant"),
                    QObject::tr("Erreur !.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
}

void modifier::on_id_sai_mod_editingFinished()
{
    QSqlQuery query;
    QString a=ui->id_sai_mod->text();
    query.prepare(
            "SELECT * FROM annonces WHERE id = :id");
    query.bindValue(":id",a);
    query.exec();
    query.first();
    QString Nom = query.value(5).toString();
    QString type = query.value(1).toString();
    QString prix = query.value(2).toString();
    ui->id_mod->setText(a);
    ui->nom_mod->setText(Nom);
    ui->type_ann_mod->setText(type);
    ui->prix_mod->setText(prix);
    if(type == "hotel")
    {
    query.prepare(
            "SELECT * FROM hotels WHERE id = :id");
    query.bindValue(":id",a);
    query.exec();
    query.first();
    QString service = query.value(3).toString();
    QString hebergement = query.value(1).toString();
    QString nbr_nuit = query.value(2).toString();

    ui->service_mod->setText(service);
    ui->hebergement_mod->setText(hebergement);
    ui->nombre_nuit_mod->setText(nbr_nuit);
    }
    if(type == "transport")
    {
    query.prepare(
            "SELECT * FROM transport WHERE id = :id");
    query.bindValue(":id",a);
    query.exec();
    query.first();
    QString type_tr = query.value(6).toString();
    QString duree_tr = query.value(8).toString();
    QString circuit = query.value(7).toString();

    ui->type_tr_mod->setText(type_tr);
    ui->duree_tr_mod->setText(duree_tr);
    ui->circuit_mod->setText(circuit);
    }
    if(type == "croisiere")
    {
    query.prepare(
            "SELECT * FROM croisiere WHERE id = :id");
    query.bindValue(":id",a);
    query.exec();
    query.first();
    QString escale = query.value(6).toString();
    QString duree_cr = query.value(8).toString();
    QString destination = query.value(7).toString();

    ui->escale_mod->setText(escale);
    ui->duree_cr_mod->setText(duree_cr);
    ui->destination_mod->setText(destination);
    }
    if(type == "companie_aerienne")
    {
    query.prepare(
            "SELECT * FROM companies_aerienne WHERE id = :id");
    query.bindValue(":id",a);
    query.exec();
    query.first();
    QString ville_dp = query.value(8).toString();
    QString ville_ar = query.value(7).toString();
    QString classe = query.value(6).toString();

    ui->classe->setText(classe);
    ui->ville_dp_mod->setText(ville_dp);
    ui->ville_ar_mod->setText(ville_ar);
    }


}

void modifier::on_supprimer_2_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annoces")
    {    supprimer s;
    s.show();
    modifier::hide();
    s.exec();}
    else {
        supprimer_promo s;
        s.show();
        modifier::hide();
        s.exec();
    }
}

void modifier::on_modifier_3_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "promotions")
    {
        modifier_promo m;
        m.show();
        modifier::hide();
        m.exec();
    }
}

void modifier::on_ajouter_2_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {ajout a;
    a.show();
    modifier::hide();
    a.exec();}
    else {
        ajut_promo a;
        a.show();
        modifier::hide();
        a.show();
    }
}

void modifier::on_supprimer_clicked()
{
    supprimer s;
    s.show();
    modifier::hide();
    s.exec();
}
