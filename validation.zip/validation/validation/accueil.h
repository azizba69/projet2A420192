#ifndef ACCUEIL_H
#define ACCUEIL_H

#include <QDialog>
#include "annonces.h"
#include "promotions.h"
namespace Ui {
class accueil;
}

class accueil : public QDialog
{
    Q_OBJECT

public:
    explicit accueil(QWidget *parent = nullptr);
    ~accueil();

private slots:

    void on_modifier_clicked();

    void on_supprimer_clicked();

    void on_afficher_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();


    void on_pro_ou_ann_currentIndexChanged(const QString &arg1);

    void on_mod_pro_ou_ann_currentIndexChanged(const QString &arg1);

    void on_sup_pro_ou_ann_currentIndexChanged(const QString &arg1);

    void on_tri_p_clicked();

private:
    Ui::accueil *ui;
    annonces tmpannonces;
    promotions tmpromotions;
};

#endif // ACCUEIL_H
