#include "supprimer.h"
#include "ui_supprimer.h"
#include "accueil.h"
#include "ajout.h"
#include "modifier.h"
#include <QMessageBox>
#include "ajut_promo.h"
#include "modifier_promo.h"
#include "supprimer_promo.h"
#include <QPropertyAnimation>
supprimer::supprimer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::supprimer)
{
    ui->setupUi(this);

}

supprimer::~supprimer()
{
    delete ui;
}

void supprimer::on_pushButton_clicked()
{
    QString id = ui->id_supp->text();
    bool test2=tmpromotions.supprimer_promotions(id);
    bool test=tmpannonces.supprimer_ann(id);
    ui->table_annonces->setModel(tmpromotions.affciher_promotions());
    ui->table_annonces->setModel(tmpannonces.afficher_ann());//refresh

}

void supprimer::on_accueil_clicked()
{
    accueil a;
    a.show();
    supprimer::hide();
    a.exec();
}



void supprimer::on_ajouter_2_currentIndexChanged(const QString &arg1)
{
    if( arg1 == "annonces")
    {
        ajout a;
        a.show();
        supprimer::hide();
        a.exec();
    }
    else {
        ajut_promo a;
        a.show();
        supprimer::hide();
        a.exec();
    }
}

void supprimer::on_modifier_2_currentIndexChanged(const QString &arg1)
{
    if( arg1 == "annonces")
    {
        modifier a;
        a.show();
        supprimer::hide();
        a.exec();
    }
    else {
        modifier_promo a;
        a.show();
        supprimer::hide();
        a.exec();
    }
}

void supprimer::on_supprimer_3_currentIndexChanged(const QString &arg1)
{
    if( arg1 == "annonces")
    {
        supprimer_promo a;
        a.show();
        supprimer::hide();
        a.exec();
    }
}

void supprimer::on_checkBox_2_clicked()
{
    ui->table_annonces->setModel(tmpromotions.affciher_promotions());
}

void supprimer::on_checkBox_clicked()
{
    ui->table_annonces->setModel(tmpannonces.afficher_ann());
}
