#ifndef AJOUT_H
#define AJOUT_H

#include <QDialog>
#include "annonces.h"
namespace Ui {
class ajout;
}

class ajout : public QDialog
{
    Q_OBJECT

public:
    explicit ajout(QWidget *parent = nullptr);
    ~ajout();

private slots:

    void on_accueil_clicked();

    void on_type_editingFinished();

    void on_id_editingFinished();

    void on_confirmer_clicked();

    void on_ajouter_2_currentIndexChanged(const QString &arg1);

    void on_modifier_2_currentIndexChanged(const QString &arg1);

    void on_supprimer_2_currentIndexChanged(const QString &arg1);

    void on_supprimer_clicked();

private:
    Ui::ajout *ui;
    annonces tmpannonces;
};

#endif // AJOUT_H
