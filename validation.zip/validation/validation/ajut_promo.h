#ifndef AJUT_PROMO_H
#define AJUT_PROMO_H

#include <QDialog>

namespace Ui {
class ajut_promo;
}

class ajut_promo : public QDialog
{
    Q_OBJECT

public:
    explicit ajut_promo(QWidget *parent = nullptr);
    ~ajut_promo();

private slots:
    void on_confirmer_clicked();

    void on_acceuil_clicked();

    void on_ajouter_2_currentIndexChanged(const QString &arg1);

    void on_modifie_currentIndexChanged(const QString &arg1);

    void on_afficher_2_currentIndexChanged(const QString &arg1);

    void on_supprimer_2_currentIndexChanged(const QString &arg1);

    void on_supprimer_clicked();

private:
    Ui::ajut_promo *ui;
};

#endif // AJUT_PROMO_H
