#ifndef SUPPRIMER_H
#define SUPPRIMER_H

#include <QDialog>
#include "annonces.h"
#include "promotions.h"
namespace Ui {
class supprimer;
}

class supprimer : public QDialog
{
    Q_OBJECT

public:
    explicit supprimer(QWidget *parent = nullptr);
    ~supprimer();

private slots:
    void on_pushButton_clicked();
    void on_accueil_clicked();


    void on_ajouter_2_currentIndexChanged(const QString &arg1);

    void on_modifier_2_currentIndexChanged(const QString &arg1);

    void on_supprimer_3_currentIndexChanged(const QString &arg1);

    void on_checkBox_2_clicked();

    void on_checkBox_clicked();

private:
    Ui::supprimer *ui;
    annonces tmpannonces;
    promotions tmpromotions;
};

#endif // SUPPRIMER_H
