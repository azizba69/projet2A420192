#include "promotions.h"

promotions::promotions()
{

}
promotions::promotions(QString a, QString b, QString c, double d )
{
    this->ID_pro = a;
    this->nom = b;
    this->type = c;
    this->prix = d;
}
bool promotions::ajouter_promotions()
{
    QSqlQuery query;
    QString res=QString::number(prix);
    query.prepare("INSERT INTO promotions (id,nom,type,prix) VALUES (:id, :nom, :type, :prix)");
    query.bindValue(":id",ID_pro);
    query.bindValue(":nom",nom);
    query.bindValue(":type",type);
    query.bindValue(":prix",res);
    return query.exec();
}
bool promotions::modifier_promotions(QString id, QString nom, QString type, double prix)
{
    QSqlQuery query;
    QString res=QString::number(prix);
    query.prepare("UPDATE promotions SET nom = :nom,type = :type,prix = :prix  WHERE ID = :id ");
    query.bindValue(":id",id);
    query.bindValue(":nom",nom);
    query.bindValue(":type",type);
    query.bindValue(":prix",res);
    return    query.exec();
}
bool promotions::supprimer_promotions(QString idd)
{
    QSqlQuery query;

    query.prepare("Delete from promotions where ID = :id ");
    query.bindValue(":id", idd);
    return    query.exec();
}
 QSqlQueryModel * promotions::affciher_promotions()
 {
     QSqlQueryModel * model= new QSqlQueryModel();

     model->setQuery("select * from promotions");
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
     model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
     model->setHeaderData(2, Qt::Horizontal, QObject::tr("type"));
     model->setHeaderData(3, Qt::Horizontal, QObject::tr("prix"));

     return model;
 }
 QSqlQueryModel * promotions::tri()
 {
     QSqlQueryModel * model= new QSqlQueryModel();
     model->setQuery("SELECT * FROM promotions ORDER BY prix");
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
     model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
     model->setHeaderData(2, Qt::Horizontal, QObject::tr("type"));
     model->setHeaderData(3, Qt::Horizontal, QObject::tr("prix"));
     return model;
 }
 QSqlQueryModel * promotions::rechercher(QString id)
 {
     QSqlQueryModel * model= new QSqlQueryModel();
     QSqlQuery query;
     query.prepare("SELECT * FROM annonces where id = :id");
     query.bindValue(":id",id);
     query.exec();
     model->setQuery(query);
     model->setHeaderData(0, Qt::Horizontal, QObject::tr("id"));
     model->setHeaderData(1, Qt::Horizontal, QObject::tr("nom"));
     model->setHeaderData(2, Qt::Horizontal, QObject::tr("type"));
     model->setHeaderData(3, Qt::Horizontal, QObject::tr("prix"));
         return model;
 }
