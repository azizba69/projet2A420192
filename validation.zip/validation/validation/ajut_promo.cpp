#include "ajut_promo.h"
#include "ui_ajut_promo.h"
#include "promotions.h"
#include "accueil.h"
#include "ajout.h"
#include "modifier.h"
#include "supprimer.h"
#include "modifier_promo.h"
#include "supprimer_promo.h"
ajut_promo::ajut_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ajut_promo)
{
    ui->setupUi(this);
}

ajut_promo::~ajut_promo()
{
    delete ui;
}

void ajut_promo::on_confirmer_clicked()
{
    QString id = ui->id_promo->text();
    QString nom = ui->nom->text();
    QString type = ui->type->text();
    double prix = ui->prix->text().toDouble();

    promotions p(id,nom,type,prix);
    bool test = p.ajouter_promotions();
}

void ajut_promo::on_acceuil_clicked()
{
    accueil a;
    a.show();
    ajut_promo::hide();
    a.exec();
}

void ajut_promo::on_ajouter_2_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        ajout a;
        a.show();
        ajut_promo::hide();
        a.exec();
    }
}

void ajut_promo::on_modifie_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        modifier m;
        m.show();
        ajut_promo::hide();
        m.exec();
    }
    else {
        modifier_promo m;
        m.show();
        ajut_promo::hide();
        m.exec();
    }
}

void ajut_promo::on_afficher_2_currentIndexChanged(const QString &arg1)
{

}

void ajut_promo::on_supprimer_2_currentIndexChanged(const QString &arg1)
{
    if(arg1 == "annonces")
    {
        supprimer m;
        m.show();
        ajut_promo::hide();
        m.exec();
    }
    else {
        supprimer_promo m;
        m.show();
        ajut_promo::hide();
        m.exec();
    }
}

void ajut_promo::on_supprimer_clicked()
{
    supprimer s;
    s.show();
    ajut_promo::hide();
    s.exec();
}
