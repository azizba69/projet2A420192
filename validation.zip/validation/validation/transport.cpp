#include "transport.h"

transport::transport()
{

}
transport::transport(QString e,QString a,double d,QString c)
{
    this->type = a;
    this->duree = d;
    this->circuit = c;
    this->ID_tr =e;
}
bool transport::ajouter_transport(QString e, QDate a, QDate b, QString c, double d)
{
    QSqlQuery query;
    QString res=QString::number(d);
    QString res1=QString::number(duree);
    query.prepare("INSERT INTO transport(id,date_fin,date_debut,nom,type,prix,type_tr,duree,circuit) "
              "VALUES (:id, :date_fin, :date_debut, :nom, :type, :prix , :type_tr, :duree, :circuit)");
    query.bindValue(":id",ID_tr);
    query.bindValue(":type",e);
    query.bindValue(":date_debut",a);
    query.bindValue(":date_fin",b);
    query.bindValue(":nom",c);
    query.bindValue(":prix",res);
    query.bindValue(":type_tr",type);
    query.bindValue(":duree",res1);
    query.bindValue(":circuit",circuit);
    return query.exec();
}
