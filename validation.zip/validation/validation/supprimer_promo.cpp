#include "supprimer_promo.h"
#include "ui_supprimer_promo.h"

supprimer_promo::supprimer_promo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::supprimer_promo)
{
    ui->setupUi(this);
}

supprimer_promo::~supprimer_promo()
{
    delete ui;
}
