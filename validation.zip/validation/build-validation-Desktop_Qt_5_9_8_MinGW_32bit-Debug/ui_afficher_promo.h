/********************************************************************************
** Form generated from reading UI file 'afficher_promo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AFFICHER_PROMO_H
#define UI_AFFICHER_PROMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_afficher_promo
{
public:

    void setupUi(QDialog *afficher_promo)
    {
        if (afficher_promo->objectName().isEmpty())
            afficher_promo->setObjectName(QStringLiteral("afficher_promo"));
        afficher_promo->resize(1920, 1080);

        retranslateUi(afficher_promo);

        QMetaObject::connectSlotsByName(afficher_promo);
    } // setupUi

    void retranslateUi(QDialog *afficher_promo)
    {
        afficher_promo->setWindowTitle(QApplication::translate("afficher_promo", "Dialog", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class afficher_promo: public Ui_afficher_promo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AFFICHER_PROMO_H
