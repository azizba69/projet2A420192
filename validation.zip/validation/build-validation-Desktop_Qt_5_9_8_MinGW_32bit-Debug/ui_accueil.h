/********************************************************************************
** Form generated from reading UI file 'accueil.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCUEIL_H
#define UI_ACCUEIL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_accueil
{
public:
    QPushButton *pushButton;
    QPushButton *ajout;
    QPushButton *modifier;
    QPushButton *supprimer;
    QPushButton *afficher;
    QTableView *table_annonces;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QLineEdit *a;
    QGraphicsView *graphicsView;
    QCalendarWidget *calendarWidget;
    QComboBox *pro_ou_ann;
    QComboBox *mod_pro_ou_ann;
    QComboBox *aff_pro_ou_ann;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QTableView *tab_a;
    QTableView *tab_p;
    QPushButton *tri_p;
    QPushButton *c_p;
    QLineEdit *r_p;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton_4;
    QPushButton *pushButton_6;
    QPushButton *pushButton_5;
    QLabel *label_7;

    void setupUi(QDialog *accueil)
    {
        if (accueil->objectName().isEmpty())
            accueil->setObjectName(QStringLiteral("accueil"));
        accueil->resize(1920, 1080);
        accueil->setStyleSheet(QStringLiteral(""));
        pushButton = new QPushButton(accueil);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(620, 20, 121, 41));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QStringLiteral("color: rgb(0, 85, 255);"));
        pushButton->setFlat(true);
        ajout = new QPushButton(accueil);
        ajout->setObjectName(QStringLiteral("ajout"));
        ajout->setGeometry(QRect(840, 20, 131, 41));
        ajout->setFont(font);
        ajout->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        ajout->setFlat(true);
        modifier = new QPushButton(accueil);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setGeometry(QRect(1050, 20, 141, 41));
        modifier->setFont(font);
        modifier->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        modifier->setFlat(true);
        supprimer = new QPushButton(accueil);
        supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->setGeometry(QRect(1250, 20, 171, 41));
        supprimer->setFont(font);
        supprimer->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        supprimer->setFlat(true);
        afficher = new QPushButton(accueil);
        afficher->setObjectName(QStringLiteral("afficher"));
        afficher->setGeometry(QRect(1480, 20, 141, 41));
        afficher->setFont(font);
        afficher->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        afficher->setFlat(true);
        table_annonces = new QTableView(accueil);
        table_annonces->setObjectName(QStringLiteral("table_annonces"));
        table_annonces->setGeometry(QRect(630, 200, 831, 421));
        table_annonces->setStyleSheet(QLatin1String("background-image: url(:/back2.png);\n"
"\n"
""));
        pushButton_2 = new QPushButton(accueil);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(890, 1000, 93, 28));
        pushButton_3 = new QPushButton(accueil);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(680, 1010, 93, 28));
        a = new QLineEdit(accueil);
        a->setObjectName(QStringLiteral("a"));
        a->setGeometry(QRect(670, 990, 113, 22));
        graphicsView = new QGraphicsView(accueil);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, -10, 1920, 1080));
        graphicsView->setStyleSheet(QStringLiteral("background-image: url(:/accueil.png);"));
        calendarWidget = new QCalendarWidget(accueil);
        calendarWidget->setObjectName(QStringLiteral("calendarWidget"));
        calendarWidget->setGeometry(QRect(1480, 210, 401, 421));
        calendarWidget->setStyleSheet(QLatin1String("color: rgb(0, 0, 0);\n"
"background-color: rgb(170, 247, 255);"));
        pro_ou_ann = new QComboBox(accueil);
        pro_ou_ann->setObjectName(QStringLiteral("pro_ou_ann"));
        pro_ou_ann->setGeometry(QRect(850, 70, 111, 22));
        pro_ou_ann->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        mod_pro_ou_ann = new QComboBox(accueil);
        mod_pro_ou_ann->setObjectName(QStringLiteral("mod_pro_ou_ann"));
        mod_pro_ou_ann->setGeometry(QRect(1060, 70, 121, 22));
        mod_pro_ou_ann->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        aff_pro_ou_ann = new QComboBox(accueil);
        aff_pro_ou_ann->setObjectName(QStringLiteral("aff_pro_ou_ann"));
        aff_pro_ou_ann->setGeometry(QRect(1490, 70, 121, 22));
        aff_pro_ou_ann->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        label = new QLabel(accueil);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 220, 171, 31));
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(false);
        font1.setWeight(50);
        label->setFont(font1);
        label->setStyleSheet(QLatin1String("\n"
"color: rgb(213, 213, 213);"));
        label_2 = new QLabel(accueil);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(90, 270, 111, 61));
        QFont font2;
        font2.setPointSize(30);
        font2.setBold(true);
        font2.setWeight(75);
        label_2->setFont(font2);
        label_3 = new QLabel(accueil);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(230, 220, 81, 21));
        QFont font3;
        font3.setPointSize(15);
        font3.setBold(true);
        font3.setWeight(75);
        label_3->setFont(font3);
        label_3->setStyleSheet(QStringLiteral("color: rgb(0, 170, 0);"));
        tab_a = new QTableView(accueil);
        tab_a->setObjectName(QStringLiteral("tab_a"));
        tab_a->setGeometry(QRect(630, 630, 411, 351));
        tab_p = new QTableView(accueil);
        tab_p->setObjectName(QStringLiteral("tab_p"));
        tab_p->setGeometry(QRect(1050, 630, 411, 351));
        tri_p = new QPushButton(accueil);
        tri_p->setObjectName(QStringLiteral("tri_p"));
        tri_p->setGeometry(QRect(1310, 1000, 93, 28));
        c_p = new QPushButton(accueil);
        c_p->setObjectName(QStringLiteral("c_p"));
        c_p->setGeometry(QRect(1120, 1010, 93, 28));
        r_p = new QLineEdit(accueil);
        r_p->setObjectName(QStringLiteral("r_p"));
        r_p->setGeometry(QRect(1110, 990, 113, 22));
        label_4 = new QLabel(accueil);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(350, 210, 151, 41));
        QFont font4;
        font4.setPointSize(20);
        label_4->setFont(font4);
        label_4->setStyleSheet(QStringLiteral("color: rgb(213, 213, 213);"));
        label_5 = new QLabel(accueil);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(370, 275, 131, 51));
        label_5->setFont(font2);
        label_6 = new QLabel(accueil);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(510, 210, 81, 41));
        label_6->setFont(font3);
        label_6->setStyleSheet(QStringLiteral("color: rgb(255, 0, 0);"));
        pushButton_4 = new QPushButton(accueil);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(630, 170, 831, 481));
        QIcon icon;
        icon.addFile(QStringLiteral(":/promo-msc-croisiere-derniere-minute.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_4->setIcon(icon);
        pushButton_4->setIconSize(QSize(831, 480));
        pushButton_4->setFlat(true);
        pushButton_6 = new QPushButton(accueil);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(22, 367, 611, 381));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/image_1568460216.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_6->setIcon(icon1);
        pushButton_6->setIconSize(QSize(1000, 700));
        pushButton_6->setFlat(true);
        pushButton_5 = new QPushButton(accueil);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(42, 767, 571, 261));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/statistiques.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_5->setIcon(icon2);
        pushButton_5->setIconSize(QSize(900, 500));
        pushButton_5->setFlat(true);
        label_7 = new QLabel(accueil);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(1480, 650, 251, 51));
        label_7->setFont(font1);
        graphicsView->raise();
        pushButton->raise();
        ajout->raise();
        modifier->raise();
        supprimer->raise();
        afficher->raise();
        table_annonces->raise();
        pushButton_2->raise();
        pushButton_3->raise();
        a->raise();
        calendarWidget->raise();
        pro_ou_ann->raise();
        mod_pro_ou_ann->raise();
        aff_pro_ou_ann->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        tab_a->raise();
        tab_p->raise();
        tri_p->raise();
        c_p->raise();
        r_p->raise();
        label_4->raise();
        label_5->raise();
        label_6->raise();
        pushButton_4->raise();
        pushButton_6->raise();
        pushButton_5->raise();
        label_7->raise();

        retranslateUi(accueil);

        QMetaObject::connectSlotsByName(accueil);
    } // setupUi

    void retranslateUi(QDialog *accueil)
    {
        accueil->setWindowTitle(QApplication::translate("accueil", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("accueil", "Accueil", Q_NULLPTR));
        ajout->setText(QApplication::translate("accueil", "Ajouter", Q_NULLPTR));
        modifier->setText(QApplication::translate("accueil", "Modifier", Q_NULLPTR));
        supprimer->setText(QApplication::translate("accueil", "Supprimer", Q_NULLPTR));
        afficher->setText(QApplication::translate("accueil", "Afficher", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("accueil", "trier", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("accueil", "chercher", Q_NULLPTR));
        pro_ou_ann->clear();
        pro_ou_ann->insertItems(0, QStringList()
         << QApplication::translate("accueil", "choisir", Q_NULLPTR)
         << QApplication::translate("accueil", "promotions", Q_NULLPTR)
         << QApplication::translate("accueil", "annonces", Q_NULLPTR)
        );
        mod_pro_ou_ann->clear();
        mod_pro_ou_ann->insertItems(0, QStringList()
         << QApplication::translate("accueil", "choisir", Q_NULLPTR)
         << QApplication::translate("accueil", "promotions", Q_NULLPTR)
         << QApplication::translate("accueil", "annonces", Q_NULLPTR)
        );
        aff_pro_ou_ann->clear();
        aff_pro_ou_ann->insertItems(0, QStringList()
         << QApplication::translate("accueil", "choisir", Q_NULLPTR)
         << QApplication::translate("accueil", "promotions", Q_NULLPTR)
         << QApplication::translate("accueil", "annonces", Q_NULLPTR)
        );
        label->setText(QApplication::translate("accueil", "Promotions", Q_NULLPTR));
        label_2->setText(QApplication::translate("accueil", "250", Q_NULLPTR));
        label_3->setText(QApplication::translate("accueil", "+42%", Q_NULLPTR));
        tri_p->setText(QApplication::translate("accueil", "trier", Q_NULLPTR));
        c_p->setText(QApplication::translate("accueil", "chercher", Q_NULLPTR));
        label_4->setText(QApplication::translate("accueil", "Annonces", Q_NULLPTR));
        label_5->setText(QApplication::translate("accueil", "1500", Q_NULLPTR));
        label_6->setText(QApplication::translate("accueil", "-27%", Q_NULLPTR));
        pushButton_4->setText(QString());
        pushButton_6->setText(QString());
        pushButton_5->setText(QString());
        label_7->setText(QApplication::translate("accueil", "T\303\242ches du jour", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class accueil: public Ui_accueil {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCUEIL_H
