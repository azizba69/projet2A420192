/********************************************************************************
** Form generated from reading UI file 'ajout.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJOUT_H
#define UI_AJOUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ajout
{
public:
    QLineEdit *type;
    QLineEdit *prix;
    QLineEdit *nom;
    QLineEdit *id;
    QLineEdit *duree_tr;
    QLineEdit *circuit;
    QLineEdit *destination;
    QLineEdit *escale;
    QLineEdit *duree_cr;
    QLineEdit *hebergement;
    QLineEdit *nombre_nuit;
    QLineEdit *service;
    QLineEdit *type_tr;
    QLineEdit *classe;
    QLineEdit *ville_ar;
    QLineEdit *ville_dp;
    QPushButton *accueil;
    QPushButton *ajouter;
    QPushButton *modifier;
    QPushButton *supprimer;
    QPushButton *affiche;
    QPushButton *confirmer;
    QDateEdit *fin;
    QDateEdit *debut;
    QGraphicsView *graphicsView;
    QComboBox *ajouter_2;
    QComboBox *modifier_2;
    QComboBox *afficher;

    void setupUi(QDialog *ajout)
    {
        if (ajout->objectName().isEmpty())
            ajout->setObjectName(QStringLiteral("ajout"));
        ajout->resize(1920, 1080);
        ajout->setStyleSheet(QStringLiteral(""));
        type = new QLineEdit(ajout);
        type->setObjectName(QStringLiteral("type"));
        type->setEnabled(true);
        type->setGeometry(QRect(130, 470, 281, 41));
        QFont font;
        font.setPointSize(20);
        type->setFont(font);
        prix = new QLineEdit(ajout);
        prix->setObjectName(QStringLiteral("prix"));
        prix->setEnabled(true);
        prix->setGeometry(QRect(130, 590, 281, 41));
        prix->setFont(font);
        nom = new QLineEdit(ajout);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setEnabled(true);
        nom->setGeometry(QRect(130, 350, 281, 41));
        nom->setFont(font);
        id = new QLineEdit(ajout);
        id->setObjectName(QStringLiteral("id"));
        id->setEnabled(true);
        id->setGeometry(QRect(130, 240, 281, 41));
        id->setFont(font);
        duree_tr = new QLineEdit(ajout);
        duree_tr->setObjectName(QStringLiteral("duree_tr"));
        duree_tr->setEnabled(true);
        duree_tr->setGeometry(QRect(1020, 380, 381, 41));
        duree_tr->setFont(font);
        circuit = new QLineEdit(ajout);
        circuit->setObjectName(QStringLiteral("circuit"));
        circuit->setEnabled(true);
        circuit->setGeometry(QRect(1020, 290, 381, 41));
        circuit->setFont(font);
        destination = new QLineEdit(ajout);
        destination->setObjectName(QStringLiteral("destination"));
        destination->setEnabled(true);
        destination->setGeometry(QRect(540, 680, 371, 41));
        destination->setFont(font);
        escale = new QLineEdit(ajout);
        escale->setObjectName(QStringLiteral("escale"));
        escale->setEnabled(true);
        escale->setGeometry(QRect(540, 760, 371, 41));
        escale->setFont(font);
        duree_cr = new QLineEdit(ajout);
        duree_cr->setObjectName(QStringLiteral("duree_cr"));
        duree_cr->setEnabled(true);
        duree_cr->setGeometry(QRect(540, 850, 371, 41));
        duree_cr->setFont(font);
        hebergement = new QLineEdit(ajout);
        hebergement->setObjectName(QStringLiteral("hebergement"));
        hebergement->setEnabled(true);
        hebergement->setGeometry(QRect(540, 470, 371, 41));
        hebergement->setFont(font);
        nombre_nuit = new QLineEdit(ajout);
        nombre_nuit->setObjectName(QStringLiteral("nombre_nuit"));
        nombre_nuit->setEnabled(true);
        nombre_nuit->setGeometry(QRect(540, 380, 371, 41));
        nombre_nuit->setFont(font);
        service = new QLineEdit(ajout);
        service->setObjectName(QStringLiteral("service"));
        service->setEnabled(true);
        service->setGeometry(QRect(540, 290, 371, 41));
        service->setFont(font);
        type_tr = new QLineEdit(ajout);
        type_tr->setObjectName(QStringLiteral("type_tr"));
        type_tr->setEnabled(true);
        type_tr->setGeometry(QRect(1020, 470, 381, 41));
        type_tr->setFont(font);
        classe = new QLineEdit(ajout);
        classe->setObjectName(QStringLiteral("classe"));
        classe->setEnabled(true);
        classe->setGeometry(QRect(1020, 850, 381, 41));
        classe->setFont(font);
        ville_ar = new QLineEdit(ajout);
        ville_ar->setObjectName(QStringLiteral("ville_ar"));
        ville_ar->setEnabled(true);
        ville_ar->setGeometry(QRect(1020, 770, 381, 41));
        ville_ar->setFont(font);
        ville_dp = new QLineEdit(ajout);
        ville_dp->setObjectName(QStringLiteral("ville_dp"));
        ville_dp->setEnabled(true);
        ville_dp->setGeometry(QRect(1020, 680, 381, 41));
        ville_dp->setFont(font);
        accueil = new QPushButton(ajout);
        accueil->setObjectName(QStringLiteral("accueil"));
        accueil->setEnabled(true);
        accueil->setGeometry(QRect(630, 20, 121, 41));
        QFont font1;
        font1.setPointSize(18);
        font1.setBold(true);
        font1.setWeight(75);
        accueil->setFont(font1);
        accueil->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
""));
        accueil->setFlat(true);
        ajouter = new QPushButton(ajout);
        ajouter->setObjectName(QStringLiteral("ajouter"));
        ajouter->setEnabled(true);
        ajouter->setGeometry(QRect(830, 20, 131, 41));
        ajouter->setFont(font1);
        ajouter->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(0, 0, 0);\n"
"color: rgb(0, 0, 255);\n"
""));
        ajouter->setFlat(true);
        modifier = new QPushButton(ajout);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setEnabled(true);
        modifier->setGeometry(QRect(1050, 20, 131, 41));
        modifier->setFont(font1);
        modifier->setStyleSheet(QLatin1String("background-color: rgb(255, 255, 255);\n"
""));
        modifier->setFlat(true);
        supprimer = new QPushButton(ajout);
        supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->setEnabled(true);
        supprimer->setGeometry(QRect(1250, 20, 171, 41));
        supprimer->setFont(font1);
        supprimer->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        supprimer->setFlat(true);
        affiche = new QPushButton(ajout);
        affiche->setObjectName(QStringLiteral("affiche"));
        affiche->setEnabled(true);
        affiche->setGeometry(QRect(1482, 20, 131, 41));
        affiche->setFont(font1);
        affiche->setStyleSheet(QLatin1String("background-color: rgb(0, 0, 0);\n"
""));
        affiche->setFlat(true);
        confirmer = new QPushButton(ajout);
        confirmer->setObjectName(QStringLiteral("confirmer"));
        confirmer->setEnabled(true);
        confirmer->setGeometry(QRect(1530, 510, 191, 61));
        confirmer->setFont(font1);
        confirmer->setStyleSheet(QStringLiteral(""));
        confirmer->setFlat(true);
        fin = new QDateEdit(ajout);
        fin->setObjectName(QStringLiteral("fin"));
        fin->setGeometry(QRect(100, 840, 261, 41));
        QFont font2;
        font2.setPointSize(20);
        font2.setBold(true);
        font2.setWeight(75);
        fin->setFont(font2);
        debut = new QDateEdit(ajout);
        debut->setObjectName(QStringLiteral("debut"));
        debut->setGeometry(QRect(100, 720, 261, 41));
        debut->setFont(font2);
        graphicsView = new QGraphicsView(ajout);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 1920, 1080));
        graphicsView->setStyleSheet(QStringLiteral("background-image: url(:/khedma.png);"));
        ajouter_2 = new QComboBox(ajout);
        ajouter_2->setObjectName(QStringLiteral("ajouter_2"));
        ajouter_2->setGeometry(QRect(840, 60, 111, 22));
        modifier_2 = new QComboBox(ajout);
        modifier_2->setObjectName(QStringLiteral("modifier_2"));
        modifier_2->setGeometry(QRect(1050, 60, 121, 22));
        afficher = new QComboBox(ajout);
        afficher->setObjectName(QStringLiteral("afficher"));
        afficher->setGeometry(QRect(1490, 60, 121, 22));
        graphicsView->raise();
        type->raise();
        prix->raise();
        nom->raise();
        id->raise();
        duree_tr->raise();
        circuit->raise();
        destination->raise();
        escale->raise();
        duree_cr->raise();
        hebergement->raise();
        nombre_nuit->raise();
        service->raise();
        type_tr->raise();
        classe->raise();
        ville_ar->raise();
        ville_dp->raise();
        accueil->raise();
        modifier->raise();
        supprimer->raise();
        affiche->raise();
        fin->raise();
        debut->raise();
        ajouter->raise();
        confirmer->raise();
        ajouter_2->raise();
        modifier_2->raise();
        afficher->raise();

        retranslateUi(ajout);

        QMetaObject::connectSlotsByName(ajout);
    } // setupUi

    void retranslateUi(QDialog *ajout)
    {
        ajout->setWindowTitle(QApplication::translate("ajout", "Dialog", Q_NULLPTR));
        accueil->setText(QApplication::translate("ajout", "Acceuil", Q_NULLPTR));
        ajouter->setText(QApplication::translate("ajout", "Ajouter", Q_NULLPTR));
        modifier->setText(QApplication::translate("ajout", "Modifier", Q_NULLPTR));
        supprimer->setText(QApplication::translate("ajout", "Supprimer", Q_NULLPTR));
        affiche->setText(QApplication::translate("ajout", "Afficher", Q_NULLPTR));
        confirmer->setText(QApplication::translate("ajout", "Confirmer", Q_NULLPTR));
        ajouter_2->clear();
        ajouter_2->insertItems(0, QStringList()
         << QApplication::translate("ajout", "choisir", Q_NULLPTR)
         << QApplication::translate("ajout", "annonces", Q_NULLPTR)
         << QApplication::translate("ajout", "promotions", Q_NULLPTR)
        );
        modifier_2->clear();
        modifier_2->insertItems(0, QStringList()
         << QApplication::translate("ajout", "choisir", Q_NULLPTR)
         << QApplication::translate("ajout", "promotions", Q_NULLPTR)
         << QApplication::translate("ajout", "annonces", Q_NULLPTR)
        );
        afficher->clear();
        afficher->insertItems(0, QStringList()
         << QApplication::translate("ajout", "choisir", Q_NULLPTR)
         << QApplication::translate("ajout", "promotions", Q_NULLPTR)
         << QApplication::translate("ajout", "annonces", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class ajout: public Ui_ajout {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJOUT_H
