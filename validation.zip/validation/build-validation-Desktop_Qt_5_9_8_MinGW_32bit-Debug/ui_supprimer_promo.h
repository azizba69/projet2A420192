/********************************************************************************
** Form generated from reading UI file 'supprimer_promo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPPRIMER_PROMO_H
#define UI_SUPPRIMER_PROMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>

QT_BEGIN_NAMESPACE

class Ui_supprimer_promo
{
public:
    QGraphicsView *graphicsView;

    void setupUi(QDialog *supprimer_promo)
    {
        if (supprimer_promo->objectName().isEmpty())
            supprimer_promo->setObjectName(QStringLiteral("supprimer_promo"));
        supprimer_promo->resize(1920, 1080);
        graphicsView = new QGraphicsView(supprimer_promo);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 1920, 1080));

        retranslateUi(supprimer_promo);

        QMetaObject::connectSlotsByName(supprimer_promo);
    } // setupUi

    void retranslateUi(QDialog *supprimer_promo)
    {
        supprimer_promo->setWindowTitle(QApplication::translate("supprimer_promo", "Dialog", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class supprimer_promo: public Ui_supprimer_promo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPPRIMER_PROMO_H
