/********************************************************************************
** Form generated from reading UI file 'ajut_promo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AJUT_PROMO_H
#define UI_AJUT_PROMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ajut_promo
{
public:
    QGraphicsView *graphicsView;
    QLineEdit *id_promo;
    QLineEdit *reduction;
    QLineEdit *id_ann;
    QPushButton *ajouter;
    QPushButton *modifier;
    QPushButton *supprimer;
    QPushButton *afficher;
    QPushButton *acceuil;
    QPushButton *confirmer;
    QComboBox *ajouter_2;
    QComboBox *modifie;
    QComboBox *afficher_2;
    QLineEdit *nom;
    QLineEdit *type;
    QLineEdit *prix;

    void setupUi(QDialog *ajut_promo)
    {
        if (ajut_promo->objectName().isEmpty())
            ajut_promo->setObjectName(QStringLiteral("ajut_promo"));
        ajut_promo->resize(1920, 1080);
        graphicsView = new QGraphicsView(ajut_promo);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 1920, 1080));
        graphicsView->setStyleSheet(QStringLiteral("background-image: url(:/ajouter-promo-v1.png);"));
        id_promo = new QLineEdit(ajut_promo);
        id_promo->setObjectName(QStringLiteral("id_promo"));
        id_promo->setGeometry(QRect(90, 321, 321, 41));
        QFont font;
        font.setPointSize(18);
        id_promo->setFont(font);
        reduction = new QLineEdit(ajut_promo);
        reduction->setObjectName(QStringLiteral("reduction"));
        reduction->setGeometry(QRect(210, 441, 211, 41));
        reduction->setFont(font);
        id_ann = new QLineEdit(ajut_promo);
        id_ann->setObjectName(QStringLiteral("id_ann"));
        id_ann->setGeometry(QRect(260, 611, 161, 41));
        id_ann->setFont(font);
        ajouter = new QPushButton(ajut_promo);
        ajouter->setObjectName(QStringLiteral("ajouter"));
        ajouter->setGeometry(QRect(830, 20, 150, 50));
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        ajouter->setFont(font1);
        ajouter->setStyleSheet(QStringLiteral("color: rgb(0, 0, 255);"));
        ajouter->setFlat(true);
        modifier = new QPushButton(ajut_promo);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setGeometry(QRect(1050, 20, 150, 50));
        modifier->setFont(font1);
        modifier->setFlat(true);
        supprimer = new QPushButton(ajut_promo);
        supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->setGeometry(QRect(1240, 20, 191, 50));
        supprimer->setFont(font1);
        supprimer->setFlat(true);
        afficher = new QPushButton(ajut_promo);
        afficher->setObjectName(QStringLiteral("afficher"));
        afficher->setGeometry(QRect(1480, 20, 150, 50));
        afficher->setFont(font1);
        afficher->setFlat(true);
        acceuil = new QPushButton(ajut_promo);
        acceuil->setObjectName(QStringLiteral("acceuil"));
        acceuil->setGeometry(QRect(610, 20, 150, 50));
        acceuil->setFont(font1);
        acceuil->setFlat(true);
        confirmer = new QPushButton(ajut_promo);
        confirmer->setObjectName(QStringLiteral("confirmer"));
        confirmer->setGeometry(QRect(1490, 450, 211, 71));
        confirmer->setFont(font1);
        confirmer->setFlat(true);
        ajouter_2 = new QComboBox(ajut_promo);
        ajouter_2->setObjectName(QStringLiteral("ajouter_2"));
        ajouter_2->setGeometry(QRect(830, 80, 141, 22));
        modifie = new QComboBox(ajut_promo);
        modifie->setObjectName(QStringLiteral("modifie"));
        modifie->setGeometry(QRect(1050, 80, 141, 22));
        afficher_2 = new QComboBox(ajut_promo);
        afficher_2->setObjectName(QStringLiteral("afficher_2"));
        afficher_2->setGeometry(QRect(1480, 80, 151, 22));
        nom = new QLineEdit(ajut_promo);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(640, 400, 421, 41));
        nom->setFont(font);
        type = new QLineEdit(ajut_promo);
        type->setObjectName(QStringLiteral("type"));
        type->setGeometry(QRect(640, 510, 421, 41));
        type->setFont(font);
        prix = new QLineEdit(ajut_promo);
        prix->setObjectName(QStringLiteral("prix"));
        prix->setGeometry(QRect(630, 630, 421, 41));
        prix->setFont(font);

        retranslateUi(ajut_promo);

        QMetaObject::connectSlotsByName(ajut_promo);
    } // setupUi

    void retranslateUi(QDialog *ajut_promo)
    {
        ajut_promo->setWindowTitle(QApplication::translate("ajut_promo", "Dialog", Q_NULLPTR));
        ajouter->setText(QApplication::translate("ajut_promo", "Ajouter", Q_NULLPTR));
        modifier->setText(QApplication::translate("ajut_promo", "Modifier", Q_NULLPTR));
        supprimer->setText(QApplication::translate("ajut_promo", "Supprimer", Q_NULLPTR));
        afficher->setText(QApplication::translate("ajut_promo", "Afficher", Q_NULLPTR));
        acceuil->setText(QApplication::translate("ajut_promo", "Acceuil", Q_NULLPTR));
        confirmer->setText(QApplication::translate("ajut_promo", "Confirmer", Q_NULLPTR));
        ajouter_2->clear();
        ajouter_2->insertItems(0, QStringList()
         << QApplication::translate("ajut_promo", "choisir", Q_NULLPTR)
         << QApplication::translate("ajut_promo", "promotions", Q_NULLPTR)
         << QApplication::translate("ajut_promo", "annonces", Q_NULLPTR)
        );
        modifie->clear();
        modifie->insertItems(0, QStringList()
         << QApplication::translate("ajut_promo", "choisir", Q_NULLPTR)
         << QApplication::translate("ajut_promo", "promotions", Q_NULLPTR)
         << QApplication::translate("ajut_promo", "annonces", Q_NULLPTR)
        );
        afficher_2->clear();
        afficher_2->insertItems(0, QStringList()
         << QApplication::translate("ajut_promo", "choisir", Q_NULLPTR)
         << QApplication::translate("ajut_promo", "promotions", Q_NULLPTR)
         << QApplication::translate("ajut_promo", "annonces", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class ajut_promo: public Ui_ajut_promo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AJUT_PROMO_H
