/********************************************************************************
** Form generated from reading UI file 'afficher.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AFFICHER_H
#define UI_AFFICHER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_afficher
{
public:
    QTableView *table;

    void setupUi(QDialog *afficher)
    {
        if (afficher->objectName().isEmpty())
            afficher->setObjectName(QStringLiteral("afficher"));
        afficher->resize(1920, 1080);
        table = new QTableView(afficher);
        table->setObjectName(QStringLiteral("table"));
        table->setGeometry(QRect(759, 0, 1161, 1080));

        retranslateUi(afficher);

        QMetaObject::connectSlotsByName(afficher);
    } // setupUi

    void retranslateUi(QDialog *afficher)
    {
        afficher->setWindowTitle(QApplication::translate("afficher", "Dialog", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class afficher: public Ui_afficher {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AFFICHER_H
