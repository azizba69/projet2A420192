/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QPushButton *employee;
    QPushButton *client;
    QPushButton *reservation;
    QPushButton *annonces;
    QPushButton *partenair;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1920, 1080);
        MainWindow->setStyleSheet(QLatin1String("\n"
"background-image: url(:/logintheone.png);"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        employee = new QPushButton(centralWidget);
        employee->setObjectName(QStringLiteral("employee"));
        employee->setGeometry(QRect(90, 170, 190, 198));
        employee->setStyleSheet(QLatin1String("background-image: url(:/employe.png);\n"
""));
        employee->setFlat(true);
        client = new QPushButton(centralWidget);
        client->setObjectName(QStringLiteral("client"));
        client->setGeometry(QRect(490, 170, 190, 198));
        client->setStyleSheet(QLatin1String("background-image: url(:/cleint.png);\n"
""));
        client->setFlat(true);
        reservation = new QPushButton(centralWidget);
        reservation->setObjectName(QStringLiteral("reservation"));
        reservation->setGeometry(QRect(900, 170, 190, 198));
        reservation->setStyleSheet(QStringLiteral("background-image: url(:/reservation.png);"));
        reservation->setFlat(true);
        annonces = new QPushButton(centralWidget);
        annonces->setObjectName(QStringLiteral("annonces"));
        annonces->setGeometry(QRect(1300, 170, 190, 198));
        annonces->setStyleSheet(QLatin1String("background-image: url(:/annonce.png);\n"
""));
        annonces->setFlat(true);
        partenair = new QPushButton(centralWidget);
        partenair->setObjectName(QStringLiteral("partenair"));
        partenair->setGeometry(QRect(1660, 170, 190, 198));
        partenair->setStyleSheet(QLatin1String("background-image: url(:/partenaireee.png);\n"
""));
        partenair->setFlat(true);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1920, 26));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        employee->setText(QString());
        client->setText(QString());
        reservation->setText(QString());
        annonces->setText(QString());
        partenair->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
