/********************************************************************************
** Form generated from reading UI file 'modifier_promo.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODIFIER_PROMO_H
#define UI_MODIFIER_PROMO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_modifier_promo
{
public:
    QGraphicsView *graphicsView;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QComboBox *ajouter;
    QComboBox *modifier;
    QComboBox *afficher;
    QLineEdit *id;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLineEdit *nom;
    QLineEdit *type;
    QLineEdit *prix;
    QLineEdit *id_mod;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;

    void setupUi(QDialog *modifier_promo)
    {
        if (modifier_promo->objectName().isEmpty())
            modifier_promo->setObjectName(QStringLiteral("modifier_promo"));
        modifier_promo->resize(1920, 1080);
        graphicsView = new QGraphicsView(modifier_promo);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 1920, 1080));
        graphicsView->setStyleSheet(QStringLiteral("background-image: url(:/Modifier-promo-v1.png);"));
        pushButton = new QPushButton(modifier_promo);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(610, 30, 141, 40));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        pushButton->setFont(font);
        pushButton->setFlat(true);
        pushButton_2 = new QPushButton(modifier_promo);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(830, 30, 141, 40));
        pushButton_2->setFont(font);
        pushButton_2->setFlat(true);
        pushButton_3 = new QPushButton(modifier_promo);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(1030, 30, 151, 40));
        pushButton_3->setFont(font);
        pushButton_3->setStyleSheet(QStringLiteral("color: rgb(0, 0, 255);"));
        pushButton_3->setFlat(true);
        pushButton_4 = new QPushButton(modifier_promo);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(1240, 30, 191, 40));
        pushButton_4->setFont(font);
        pushButton_4->setFlat(true);
        pushButton_5 = new QPushButton(modifier_promo);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(1480, 30, 151, 40));
        pushButton_5->setFont(font);
        pushButton_5->setFlat(true);
        ajouter = new QComboBox(modifier_promo);
        ajouter->setObjectName(QStringLiteral("ajouter"));
        ajouter->setGeometry(QRect(840, 70, 111, 22));
        modifier = new QComboBox(modifier_promo);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setGeometry(QRect(1040, 70, 131, 22));
        afficher = new QComboBox(modifier_promo);
        afficher->setObjectName(QStringLiteral("afficher"));
        afficher->setGeometry(QRect(1490, 70, 131, 22));
        id = new QLineEdit(modifier_promo);
        id->setObjectName(QStringLiteral("id"));
        id->setGeometry(QRect(590, 321, 321, 41));
        QFont font1;
        font1.setPointSize(18);
        id->setFont(font1);
        lineEdit_2 = new QLineEdit(modifier_promo);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(710, 441, 201, 41));
        lineEdit_2->setFont(font1);
        lineEdit_3 = new QLineEdit(modifier_promo);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(770, 591, 141, 41));
        lineEdit_3->setFont(font1);
        nom = new QLineEdit(modifier_promo);
        nom->setObjectName(QStringLiteral("nom"));
        nom->setGeometry(QRect(1060, 440, 401, 41));
        nom->setFont(font1);
        type = new QLineEdit(modifier_promo);
        type->setObjectName(QStringLiteral("type"));
        type->setGeometry(QRect(1060, 560, 401, 41));
        type->setFont(font1);
        prix = new QLineEdit(modifier_promo);
        prix->setObjectName(QStringLiteral("prix"));
        prix->setGeometry(QRect(1060, 660, 401, 41));
        prix->setFont(font1);
        id_mod = new QLineEdit(modifier_promo);
        id_mod->setObjectName(QStringLiteral("id_mod"));
        id_mod->setGeometry(QRect(110, 491, 281, 41));
        id_mod->setFont(font1);
        pushButton_6 = new QPushButton(modifier_promo);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(160, 620, 181, 41));
        pushButton_7 = new QPushButton(modifier_promo);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(630, 740, 181, 41));

        retranslateUi(modifier_promo);

        QMetaObject::connectSlotsByName(modifier_promo);
    } // setupUi

    void retranslateUi(QDialog *modifier_promo)
    {
        modifier_promo->setWindowTitle(QApplication::translate("modifier_promo", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("modifier_promo", "Accueil", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("modifier_promo", "Ajouter", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("modifier_promo", "Modifier", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("modifier_promo", "Supprimer", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("modifier_promo", "Afficher", Q_NULLPTR));
        ajouter->clear();
        ajouter->insertItems(0, QStringList()
         << QApplication::translate("modifier_promo", "choisir", Q_NULLPTR)
         << QApplication::translate("modifier_promo", "anoonces", Q_NULLPTR)
         << QApplication::translate("modifier_promo", "promotions", Q_NULLPTR)
        );
        modifier->clear();
        modifier->insertItems(0, QStringList()
         << QApplication::translate("modifier_promo", "choisir", Q_NULLPTR)
         << QApplication::translate("modifier_promo", "promotions", Q_NULLPTR)
         << QApplication::translate("modifier_promo", "annonces", Q_NULLPTR)
        );
        pushButton_6->setText(QApplication::translate("modifier_promo", "confirmer", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("modifier_promo", "affecter", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class modifier_promo: public Ui_modifier_promo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODIFIER_PROMO_H
