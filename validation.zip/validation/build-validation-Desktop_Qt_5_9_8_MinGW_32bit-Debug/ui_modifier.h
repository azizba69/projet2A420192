/********************************************************************************
** Form generated from reading UI file 'modifier.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MODIFIER_H
#define UI_MODIFIER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_modifier
{
public:
    QPushButton *accueil;
    QPushButton *supprimer;
    QPushButton *modifier_2;
    QPushButton *ajouter;
    QPushButton *afficher;
    QLineEdit *type_ann_mod;
    QLineEdit *prix_mod;
    QLineEdit *nom_mod;
    QLineEdit *id_mod;
    QLineEdit *id_sai_mod;
    QLineEdit *service_mod;
    QLineEdit *nombre_nuit_mod;
    QLineEdit *hebergement_mod;
    QLineEdit *destination_mod;
    QLineEdit *duree_cr_mod;
    QLineEdit *escale_mod;
    QLineEdit *circuit_mod;
    QLineEdit *duree_tr_mod;
    QLineEdit *type_tr_mod;
    QLineEdit *ville_dp_mod;
    QLineEdit *ville_ar_mod;
    QLineEdit *classe;
    QDateEdit *fin_mod;
    QDateEdit *debut_mod;
    QPushButton *confirmer;
    QGraphicsView *graphicsView;
    QComboBox *comboBox;
    QComboBox *comboBox_2;
    QComboBox *comboBox_4;

    void setupUi(QDialog *modifier)
    {
        if (modifier->objectName().isEmpty())
            modifier->setObjectName(QStringLiteral("modifier"));
        modifier->resize(1920, 1080);
        modifier->setStyleSheet(QStringLiteral(""));
        accueil = new QPushButton(modifier);
        accueil->setObjectName(QStringLiteral("accueil"));
        accueil->setGeometry(QRect(630, 30, 121, 41));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        accueil->setFont(font);
        accueil->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        accueil->setFlat(true);
        supprimer = new QPushButton(modifier);
        supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->setGeometry(QRect(1250, 30, 171, 41));
        supprimer->setFont(font);
        supprimer->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        supprimer->setFlat(true);
        modifier_2 = new QPushButton(modifier);
        modifier_2->setObjectName(QStringLiteral("modifier_2"));
        modifier_2->setGeometry(QRect(1050, 30, 141, 41));
        modifier_2->setFont(font);
        modifier_2->setStyleSheet(QStringLiteral("color: rgb(0, 85, 255);"));
        modifier_2->setFlat(true);
        ajouter = new QPushButton(modifier);
        ajouter->setObjectName(QStringLiteral("ajouter"));
        ajouter->setGeometry(QRect(840, 30, 131, 41));
        ajouter->setFont(font);
        ajouter->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        ajouter->setFlat(true);
        afficher = new QPushButton(modifier);
        afficher->setObjectName(QStringLiteral("afficher"));
        afficher->setGeometry(QRect(1490, 30, 131, 41));
        afficher->setFont(font);
        afficher->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        afficher->setFlat(true);
        type_ann_mod = new QLineEdit(modifier);
        type_ann_mod->setObjectName(QStringLiteral("type_ann_mod"));
        type_ann_mod->setGeometry(QRect(600, 510, 281, 41));
        QFont font1;
        font1.setPointSize(20);
        type_ann_mod->setFont(font1);
        prix_mod = new QLineEdit(modifier);
        prix_mod->setObjectName(QStringLiteral("prix_mod"));
        prix_mod->setGeometry(QRect(600, 630, 281, 41));
        prix_mod->setFont(font1);
        nom_mod = new QLineEdit(modifier);
        nom_mod->setObjectName(QStringLiteral("nom_mod"));
        nom_mod->setGeometry(QRect(590, 400, 291, 41));
        nom_mod->setFont(font1);
        id_mod = new QLineEdit(modifier);
        id_mod->setObjectName(QStringLiteral("id_mod"));
        id_mod->setGeometry(QRect(580, 280, 301, 41));
        id_mod->setFont(font1);
        id_sai_mod = new QLineEdit(modifier);
        id_sai_mod->setObjectName(QStringLiteral("id_sai_mod"));
        id_sai_mod->setGeometry(QRect(60, 540, 281, 41));
        id_sai_mod->setFont(font1);
        service_mod = new QLineEdit(modifier);
        service_mod->setObjectName(QStringLiteral("service_mod"));
        service_mod->setGeometry(QRect(1000, 340, 381, 41));
        service_mod->setFont(font1);
        nombre_nuit_mod = new QLineEdit(modifier);
        nombre_nuit_mod->setObjectName(QStringLiteral("nombre_nuit_mod"));
        nombre_nuit_mod->setGeometry(QRect(1000, 420, 381, 41));
        nombre_nuit_mod->setFont(font1);
        hebergement_mod = new QLineEdit(modifier);
        hebergement_mod->setObjectName(QStringLiteral("hebergement_mod"));
        hebergement_mod->setGeometry(QRect(1000, 510, 381, 41));
        hebergement_mod->setFont(font1);
        destination_mod = new QLineEdit(modifier);
        destination_mod->setObjectName(QStringLiteral("destination_mod"));
        destination_mod->setGeometry(QRect(1000, 720, 381, 41));
        destination_mod->setFont(font1);
        duree_cr_mod = new QLineEdit(modifier);
        duree_cr_mod->setObjectName(QStringLiteral("duree_cr_mod"));
        duree_cr_mod->setGeometry(QRect(1000, 890, 381, 41));
        duree_cr_mod->setFont(font1);
        escale_mod = new QLineEdit(modifier);
        escale_mod->setObjectName(QStringLiteral("escale_mod"));
        escale_mod->setGeometry(QRect(1000, 800, 381, 41));
        escale_mod->setFont(font1);
        circuit_mod = new QLineEdit(modifier);
        circuit_mod->setObjectName(QStringLiteral("circuit_mod"));
        circuit_mod->setGeometry(QRect(1490, 340, 371, 41));
        circuit_mod->setFont(font1);
        duree_tr_mod = new QLineEdit(modifier);
        duree_tr_mod->setObjectName(QStringLiteral("duree_tr_mod"));
        duree_tr_mod->setGeometry(QRect(1490, 420, 371, 41));
        duree_tr_mod->setFont(font1);
        type_tr_mod = new QLineEdit(modifier);
        type_tr_mod->setObjectName(QStringLiteral("type_tr_mod"));
        type_tr_mod->setGeometry(QRect(1490, 510, 371, 41));
        type_tr_mod->setFont(font1);
        ville_dp_mod = new QLineEdit(modifier);
        ville_dp_mod->setObjectName(QStringLiteral("ville_dp_mod"));
        ville_dp_mod->setGeometry(QRect(1490, 720, 371, 41));
        ville_dp_mod->setFont(font1);
        ville_ar_mod = new QLineEdit(modifier);
        ville_ar_mod->setObjectName(QStringLiteral("ville_ar_mod"));
        ville_ar_mod->setGeometry(QRect(1490, 810, 371, 41));
        ville_ar_mod->setFont(font1);
        classe = new QLineEdit(modifier);
        classe->setObjectName(QStringLiteral("classe"));
        classe->setGeometry(QRect(1490, 890, 371, 41));
        classe->setFont(font1);
        fin_mod = new QDateEdit(modifier);
        fin_mod->setObjectName(QStringLiteral("fin_mod"));
        fin_mod->setGeometry(QRect(570, 870, 251, 41));
        QFont font2;
        font2.setPointSize(20);
        font2.setBold(true);
        font2.setWeight(75);
        fin_mod->setFont(font2);
        debut_mod = new QDateEdit(modifier);
        debut_mod->setObjectName(QStringLiteral("debut_mod"));
        debut_mod->setGeometry(QRect(570, 770, 251, 41));
        debut_mod->setFont(font2);
        confirmer = new QPushButton(modifier);
        confirmer->setObjectName(QStringLiteral("confirmer"));
        confirmer->setGeometry(QRect(100, 660, 181, 51));
        confirmer->setFont(font);
        confirmer->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        confirmer->setFlat(true);
        graphicsView = new QGraphicsView(modifier);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 1920, 1080));
        graphicsView->setStyleSheet(QStringLiteral("background-image: url(:/modifier_ann.png);"));
        comboBox = new QComboBox(modifier);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(850, 70, 111, 22));
        comboBox_2 = new QComboBox(modifier);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(1060, 70, 121, 22));
        comboBox_4 = new QComboBox(modifier);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(1500, 70, 111, 22));
        graphicsView->raise();
        accueil->raise();
        supprimer->raise();
        modifier_2->raise();
        ajouter->raise();
        afficher->raise();
        type_ann_mod->raise();
        prix_mod->raise();
        nom_mod->raise();
        id_mod->raise();
        id_sai_mod->raise();
        service_mod->raise();
        nombre_nuit_mod->raise();
        hebergement_mod->raise();
        destination_mod->raise();
        duree_cr_mod->raise();
        escale_mod->raise();
        circuit_mod->raise();
        duree_tr_mod->raise();
        type_tr_mod->raise();
        ville_dp_mod->raise();
        ville_ar_mod->raise();
        classe->raise();
        fin_mod->raise();
        debut_mod->raise();
        confirmer->raise();
        comboBox->raise();
        comboBox_2->raise();
        comboBox_4->raise();

        retranslateUi(modifier);

        QMetaObject::connectSlotsByName(modifier);
    } // setupUi

    void retranslateUi(QDialog *modifier)
    {
        modifier->setWindowTitle(QApplication::translate("modifier", "Dialog", Q_NULLPTR));
        accueil->setText(QApplication::translate("modifier", "Accueil", Q_NULLPTR));
        supprimer->setText(QApplication::translate("modifier", "Supprimer", Q_NULLPTR));
        modifier_2->setText(QApplication::translate("modifier", "Modifier", Q_NULLPTR));
        ajouter->setText(QApplication::translate("modifier", "Ajouter", Q_NULLPTR));
        afficher->setText(QApplication::translate("modifier", "Afficher", Q_NULLPTR));
        confirmer->setText(QApplication::translate("modifier", "Confirmer", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class modifier: public Ui_modifier {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MODIFIER_H
