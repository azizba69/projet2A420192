/********************************************************************************
** Form generated from reading UI file 'supprimer.ui'
**
** Created by: Qt User Interface Compiler version 5.9.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SUPPRIMER_H
#define UI_SUPPRIMER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>

QT_BEGIN_NAMESPACE

class Ui_supprimer
{
public:
    QPushButton *pushButton;
    QLineEdit *id_supp;
    QTableView *table_annonces;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QPushButton *accueil;
    QPushButton *afficher;
    QPushButton *modifier;
    QPushButton *ajouter;
    QPushButton *supprimer_2;
    QGraphicsView *graphicsView;
    QComboBox *ajouter_2;
    QComboBox *modifier_2;
    QComboBox *comboBox_4;

    void setupUi(QDialog *supprimer)
    {
        if (supprimer->objectName().isEmpty())
            supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->resize(1920, 1080);
        supprimer->setStyleSheet(QStringLiteral(""));
        pushButton = new QPushButton(supprimer);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(210, 670, 191, 61));
        QFont font;
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        pushButton->setFont(font);
        pushButton->setStyleSheet(QStringLiteral(""));
        pushButton->setFlat(true);
        id_supp = new QLineEdit(supprimer);
        id_supp->setObjectName(QStringLiteral("id_supp"));
        id_supp->setGeometry(QRect(200, 470, 201, 41));
        QFont font1;
        font1.setPointSize(20);
        id_supp->setFont(font1);
        table_annonces = new QTableView(supprimer);
        table_annonces->setObjectName(QStringLiteral("table_annonces"));
        table_annonces->setGeometry(QRect(780, 230, 881, 651));
        table_annonces->setStyleSheet(QStringLiteral("background-image: url(:/back2.jpg);"));
        checkBox = new QCheckBox(supprimer);
        checkBox->setObjectName(QStringLiteral("checkBox"));
        checkBox->setGeometry(QRect(210, 550, 16, 20));
        checkBox_2 = new QCheckBox(supprimer);
        checkBox_2->setObjectName(QStringLiteral("checkBox_2"));
        checkBox_2->setGeometry(QRect(570, 550, 16, 20));
        checkBox_2->setTristate(true);
        accueil = new QPushButton(supprimer);
        accueil->setObjectName(QStringLiteral("accueil"));
        accueil->setGeometry(QRect(620, 30, 121, 41));
        accueil->setFont(font);
        accueil->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        accueil->setFlat(true);
        afficher = new QPushButton(supprimer);
        afficher->setObjectName(QStringLiteral("afficher"));
        afficher->setGeometry(QRect(1480, 30, 131, 41));
        afficher->setFont(font);
        afficher->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        afficher->setFlat(true);
        modifier = new QPushButton(supprimer);
        modifier->setObjectName(QStringLiteral("modifier"));
        modifier->setGeometry(QRect(1050, 30, 141, 41));
        modifier->setFont(font);
        modifier->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        modifier->setFlat(true);
        ajouter = new QPushButton(supprimer);
        ajouter->setObjectName(QStringLiteral("ajouter"));
        ajouter->setGeometry(QRect(840, 30, 131, 41));
        ajouter->setFont(font);
        ajouter->setStyleSheet(QStringLiteral("background-color: rgb(0, 0, 0);"));
        ajouter->setFlat(true);
        supprimer_2 = new QPushButton(supprimer);
        supprimer_2->setObjectName(QStringLiteral("supprimer_2"));
        supprimer_2->setGeometry(QRect(1250, 30, 171, 41));
        supprimer_2->setFont(font);
        supprimer_2->setStyleSheet(QStringLiteral("color: rgb(0, 85, 255);"));
        supprimer_2->setFlat(true);
        graphicsView = new QGraphicsView(supprimer);
        graphicsView->setObjectName(QStringLiteral("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 1920, 1080));
        graphicsView->setStyleSheet(QStringLiteral("background-image: url(:/supprimer.png);"));
        ajouter_2 = new QComboBox(supprimer);
        ajouter_2->setObjectName(QStringLiteral("ajouter_2"));
        ajouter_2->setGeometry(QRect(850, 70, 111, 22));
        modifier_2 = new QComboBox(supprimer);
        modifier_2->setObjectName(QStringLiteral("modifier_2"));
        modifier_2->setGeometry(QRect(1060, 70, 121, 22));
        comboBox_4 = new QComboBox(supprimer);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(1480, 70, 121, 22));
        graphicsView->raise();
        pushButton->raise();
        id_supp->raise();
        table_annonces->raise();
        checkBox->raise();
        checkBox_2->raise();
        accueil->raise();
        afficher->raise();
        modifier->raise();
        ajouter->raise();
        supprimer_2->raise();
        ajouter_2->raise();
        modifier_2->raise();
        comboBox_4->raise();

        retranslateUi(supprimer);

        QMetaObject::connectSlotsByName(supprimer);
    } // setupUi

    void retranslateUi(QDialog *supprimer)
    {
        supprimer->setWindowTitle(QApplication::translate("supprimer", "Dialog", Q_NULLPTR));
        pushButton->setText(QApplication::translate("supprimer", "Supprimer", Q_NULLPTR));
        checkBox->setText(QString());
        checkBox_2->setText(QString());
        accueil->setText(QApplication::translate("supprimer", "Accueil", Q_NULLPTR));
        afficher->setText(QApplication::translate("supprimer", "Afficher", Q_NULLPTR));
        modifier->setText(QApplication::translate("supprimer", "Modifier", Q_NULLPTR));
        ajouter->setText(QApplication::translate("supprimer", "Ajouter", Q_NULLPTR));
        supprimer_2->setText(QApplication::translate("supprimer", "Supprimer", Q_NULLPTR));
        ajouter_2->clear();
        ajouter_2->insertItems(0, QStringList()
         << QApplication::translate("supprimer", "choisir", Q_NULLPTR)
         << QApplication::translate("supprimer", "annonces", Q_NULLPTR)
         << QApplication::translate("supprimer", "promotions", Q_NULLPTR)
        );
        modifier_2->clear();
        modifier_2->insertItems(0, QStringList()
         << QApplication::translate("supprimer", "choisir", Q_NULLPTR)
         << QApplication::translate("supprimer", "promotions", Q_NULLPTR)
         << QApplication::translate("supprimer", "annonces", Q_NULLPTR)
        );
        comboBox_4->clear();
        comboBox_4->insertItems(0, QStringList()
         << QApplication::translate("supprimer", "choisir", Q_NULLPTR)
         << QApplication::translate("supprimer", "promotions", Q_NULLPTR)
         << QApplication::translate("supprimer", "annonces", Q_NULLPTR)
        );
    } // retranslateUi

};

namespace Ui {
    class supprimer: public Ui_supprimer {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SUPPRIMER_H
